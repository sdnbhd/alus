---
---

<br id="idx00">
# {{ site.title }}

Setiap pagi, ibu Alus berjualan Nasi Uduk di ujung simpang jalan Harapan,
sekitar 300m dari stasiun Lenteng Agung -- sebelah kanan jika mengarah ke Depok.

<br id="idx01">
<img src="images/Nasi-Uduk-Bu-Alus-20220816-0.jpg" width="80%">
<br><br>

Gerobak ibu Alus mudah ditemukan karena lokasinya betul-betul di ujung simpang jalan Harapan, Lenteng Agung.
Hanya saja, gerobaknya tanpa tanpa / tulisan informasi.

<br id="idx02">
<img src="images/Nasi-Uduk-Bu-Alus-20220816-1.jpg" width="80%">
<br><br>

Selain nasi Uduk, ibu Alus juga berjualan Lontong Sayur dan Gorengan.

<br id="idx03">
<img src="images/Nasi-Uduk-Bu-Alus-20220816-2.jpg" width="80%">

Untuk tahun 2022 ini, harga Nasi Uduk Telur Standar ialah Rp. 13000.
Kalau dengan "extra tempe", dibulatkan menjadi Rp. 15000.

<br id="idx04">
<img src="images/Nasi-Uduk-Bu-Alus-20220816-3.jpg" width="80%">
<br><br>

Syarat dan ketentuan berlaku.
Ayam Goreng dibeli secara terpisah di KFC LA Terrace, sekitar 1300m dari lokasi ibu Alus (arah Depok).

<br id="idx05">
<img src="images/QR.png" width="50%">
<br><br>

This [GitHub Page](https://pages.github.com/) is hosted at [GitHub.com]({{ site.urlgithub }}).

